/**
 * Layout component that queries for data
 * with Gatsby's useStaticQuery component
 *
 * See: https://www.gatsbyjs.com/docs/use-static-query/
 */

import * as React from "react"
import PropTypes from "prop-types"
import { useStaticQuery, graphql } from "gatsby"

import './Layout.css';
import './Main.css';
import './Style.css';
import logo from './logo.png';
import img1 from './victoria-sponge-umami.jpg';
import img2 from './umami-bundle.png';

const Layout = () => {
  
  return (
    <>
      <div className="App">


<div className="dialog-off-canvas-main-canvas" data-off-canvas-main-canvas>
    <div className="layout-container">

        <header className="layout-header" role="banner">
            <div className="container">
                <div className="region region-pre-header">
                    <div
                        className="language-switcher-language-url block block-language block-language-blocklanguage-interface"
                        id="block-umami-languageswitcher" role="navigation">


                        <ul className="links">
                            <li hreflang="en" data-drupal-link-system-path="node/5"
                                className="en is-active"><a href="/en/recipes/victoria-sponge-cake"
                                                            className="language-link is-active"
                                                            hreflang="en"
                                                            data-drupal-link-system-path="node/5">English</a>
                            </li>
                            <li hreflang="ta" data-drupal-link-system-path="node/5" className="ta"><a
                                href="/ta/node/5" className="language-link" hreflang="ta"
                                data-drupal-link-system-path="node/5">Tamil</a></li>
                        </ul>
                    </div>

                    <div className="search-iconwrap">
                        <a className="search-link" title="Go to the search page" href="/en/search">
<span className="search-icon" aria-hidden="true"><svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1"><g id="Page-1"
                                                                                            stroke="none"
                                                                                            stroke-width="1"
                                                                                            fill="none"
                                                                                            fill-rule="evenodd"><g
id="Group"><g id="search"><path
d="M5.40705882,9.76579186 L1.13049774,14.0423529 L1.95800905,14.8691403 L6.23384615,10.5925792 C5.93199325,10.3445547 5.65508327,10.0676448 5.40705882,9.76579186 L5.40705882,9.76579186 Z M10.0180995,1.21013575 C7.38262671,1.21013575 5.24615385,3.34660861 5.24615385,5.98208145 C5.24615385,8.61755429 7.38262671,10.7540271 10.0180995,10.7540271 C12.6534724,10.7540271 14.7898643,8.61763532 14.7898643,5.98226244 C14.7898643,3.34688957 12.6534724,1.21049774 10.0180995,1.21049774 L10.0180995,1.21013575 Z M6.91113122,5.46932127 C6.65303181,5.46932127 6.4438009,5.26009036 6.4438009,5.00199095 C6.4438009,4.74389154 6.65303181,4.53466063 6.91113122,4.53466063 C7.16923063,4.53466063 7.37846154,4.74389154 7.37846154,5.00199095 C7.37846154,5.12593466 7.32922509,5.24480195 7.24158366,5.33244339 C7.15394222,5.42008482 7.03507493,5.46932127 6.91113122,5.46932127 Z M7.94027149,4.33628959 C7.48843702,4.33549024 7.12272582,3.96869932 7.12325849,3.51686445 C7.12379115,3.06502958 7.49036615,2.69910196 7.94220126,2.69936794 C8.39403636,2.69963392 8.76018029,3.06599287 8.760181,3.51782805 C8.76018134,3.73514866 8.67375208,3.94354729 8.51994746,4.09708029 C8.36614283,4.2506133 8.15759176,4.33667406 7.94027149,4.33628959 Z M9.59276018,3.21158371 C9.3345954,3.21018605 9.12631234,3.00001615 9.12724286,2.74184926 C9.12817338,2.48368237 9.33796605,2.27501936 9.59613419,2.27548273 C9.85430234,2.27594609 10.0633446,2.48536085 10.0633484,2.74352941 C10.0633502,2.86810541 10.0136898,2.98754248 9.92536382,3.07539289 C9.83703781,3.16324331 9.71733436,3.21225814 9.59276018,3.21158371 L9.59276018,3.21158371 Z"></path><path
d="M10.0180995,0.0170135747 C7.91074463,0.0175014928 5.95997609,1.12971952 4.88615078,2.94296087 C3.81232547,4.75620223 3.7747616,7.00144515 4.78733032,8.84959276 C4.63937697,8.9190674 4.50463812,9.01375207 4.38914027,9.12941176 L0.430769231,13.0888688 C-0.12045472,13.6401793 -0.12045472,14.5339384 0.430769231,15.0852489 L0.914751131,15.5692308 C1.1795314,15.8341616 1.53874087,15.9830108 1.91330317,15.9830108 C2.28786547,15.9830108 2.64707494,15.8341616 2.9118552,15.5692308 L6.86950226,11.6112217 C6.98533647,11.495791 7.08015077,11.361042 7.14968326,11.2130317 C9.3343265,12.4100266 12.0327729,12.1233591 13.9171704,10.4940926 C15.8015678,8.86482619 16.4750474,6.23609712 15.606203,3.90145101 C14.7373587,1.56680491 12.509176,0.0179366079 10.0180995,0.0170135747 L10.0180995,0.0170135747 Z M1.95800905,14.8691403 L1.13049774,14.0423529 L5.40705882,9.76579186 C5.65508327,10.0676448 5.93199325,10.3445547 6.23384615,10.5925792 L1.95800905,14.8691403 Z M10.0180995,10.7536652 C7.38272668,10.7538651 5.2461728,8.61763532 5.24597288,5.98226245 C5.24577296,3.34688959 7.38200271,1.2103357 10.0173756,1.21013577 C12.6527484,1.20993585 14.7893023,3.3461656 14.7895023,5.98153846 C14.7897904,7.24736947 14.2870686,8.46143806 13.3919909,9.35651577 C12.4969132,10.2515935 11.2828446,10.7543153 10.0170136,10.7540271 L10.0180995,10.7536652 Z"
fill="#D93760" fill-rule="nonzero"></path><circle fill="#D93760" fill-rule="nonzero" cx="7.94027149"
                                              cy="3.51782805" r="1"></circle><circle fill="#D93760"
                                                                                     fill-rule="nonzero"
                                                                                     cx="9.59457014"
                                                                                     cy="2.74352941"
                                                                                     r="1"></circle><circle
fill="#D93760" fill-rule="nonzero" cx="6.91113122" cy="5.00199095" r="1"></circle></g></g></g></svg>
</span>
                            <span className="visually-hidden">Search</span>
                        </a>
                    </div>

                    <div className="search-block-form block block-search container-inline"
                         data-drupal-selector="search-block-form" id="block-umami-search" role="search">

                        <h2 className="block__title visually-hidden">Search</h2>

                        <form action="/en/search/node" method="get" id="search-block-form"
                              accept-charset="UTF-8">
                            <div
                                className="js-form-item form-item js-form-type-search form-type-search js-form-item-keys form-item-keys form-no-label">
                                <label for="edit-keys" className="visually-hidden">Search</label>
                                <input title="Enter the terms you wish to search for."
                                       placeholder="Search by keyword, ingredient, dish"
                                       data-drupal-selector="edit-keys" type="search" id="edit-keys"
                                       name="keys" value="" size="15" maxlength="128"
                                       className="form-search"/>

                            </div>
                            <div data-drupal-selector="edit-actions"
                                 className="form-actions js-form-wrapper form-wrapper" id="edit-actions">
                                <input data-drupal-selector="edit-submit" type="submit" id="edit-submit"
                                       value="Search" className="button js-form-submit form-submit"/>
                            </div>

                        </form>

                    </div>
                    <nav role="navigation" aria-labelledby="block-umami-account-menu-menu"
                         id="block-umami-account-menu"
                         className="block block-menu navigation menu--account">

                        <h2 className="block__title visually-hidden" id="block-umami-account-menu-menu">User
                            account menu</h2>


                        <ul className="menu-account">
                            <li className="menu-account__item"><a href="/en/user/login"
                                                                  className="menu-account__link"
                                                                  data-drupal-link-system-path="user/login">Log
                                in</a>
                            </li>
                        </ul>


                    </nav>

                </div>

                <div className="region region-header">
                    <div id="block-umami-branding"
                         className="block block-system block-system-branding-block">


                        <a href="/en" rel="home" className="site-logo">
                            <img src={logo} alt="Home"/>
                        </a>
                    </div>

                    <div className="menu-main-togglewrap">
                        <button type="button" name="menu_toggle" className="menu-main-toggle"
                                data-drupal-selector="menu-main-toggle" aria-label="Toggle the menu">
                            <svg width="23" height="23" viewBox="0 0 23 23">
                                <use href="#a" fill="#5F635D"/>
                                <use href="#a" transform="translate(0 18)" fill="#5F635D"/>
                                <use href="#a" transform="translate(0 9)" fill="#5F635D"/>
                                <defs>
                                    <path id="a" fill-rule="evenodd" d="M0 0h23v5H0V0z"/>
                                </defs>
                            </svg>
                        </button>
                    </div>

                    <nav role="navigation" aria-labelledby="block-umami-main-menu-menu"
                         id="block-umami-main-menu"
                         className="block block-menu navigation menu-main__wrapper">

                        <h2 className="block__title visually-hidden" id="block-umami-main-menu-menu">Main
                            navigation</h2>


                        <ul className="menu-main" data-drupal-selector="menu-main">
                            <li className="menu-main__item"><a href="/en" className="menu-main__link"
                                                               data-drupal-link-system-path="&lt;front&gt;">Home</a>
                            </li>
                            <li className="menu-main__item"><a href="/en/articles"
                                                               className="menu-main__link"
                                                               data-drupal-link-system-path="articles">Articles</a>
                            </li>
                            <li className="menu-main__item"><a href="/en/recipes"
                                                               className="menu-main__link"
                                                               data-drupal-link-system-path="recipes">Recipes</a>
                            </li>
                        </ul>


                    </nav>

                </div>

            </div>
        </header>

        <div className="layout-highlighted">
            <div className="container">
                <div className="region region-highlighted">
                    <div data-drupal-messages-fallback className="hidden"></div>

                </div>

            </div>
        </div>

        <div className="layout-tabs">
            <div className="container">

            </div>
        </div>


        <div className="layout-breadcrumbs">
            <div className="container">
                <div className="region region-breadcrumbs">
                    <div id="block-umami-breadcrumbs"
                         className="block block-system block-system-breadcrumb-block">


                        <nav className="breadcrumb" role="navigation" aria-labelledby="system-breadcrumb">
                            <h2 id="system-breadcrumb" className="visually-hidden">Breadcrumb</h2>
                            <ol>
                                <li>
                                    <a href="/en">Home</a>
                                </li>
                                <li>
                                    <a href="/en/recipes">Recipes</a>
                                </li>
                                <li> Victoria sponge cake</li>
                            </ol>
                        </nav>

                    </div>

                </div>

            </div>
        </div>


        <main role="main" className="main container">

            <div className="layout-content">
                <a id="main-content" tabindex="-1"></a>
                <div className="region region-content">
                    <div id="block-umami-content" className="block block-system block-system-main-block">


                        <article role="article" about="/en/recipes/victoria-sponge-cake"
                                 className="node node--type-recipe node--promoted node--view-mode-full">


                            <header className="node__header">
                                <h1 className="page-title">
                                    <span
                                        className="field field--name-title field--type-string field--label-hidden">Victoria sponge cake</span>

                                </h1>
                            </header>


                            <div className="node__content">
                                <div className="layout layout--onecol">
                                    <div className="layout__region layout__region--content">
                                        <div
                                            className="block block-layout-builder block-field-blocknoderecipefield-recipe-category">


                                            <div
                                                className="label-items field field--name-field-recipe-category field--type-entity-reference field--label-inline clearfix">
                                                <div className="field__label">Recipe category</div>
                                                <div className="field__items">
                                                    <div className="field__item"><a
                                                        href="/en/recipe-category/desserts"
                                                        hreflang="en">Desserts</a></div>
                                                </div>
                                            </div>

                                        </div>
                                        <div
                                            className="block block-layout-builder block-field-blocknoderecipefield-tags">


                                            <div
                                                className="label-items field field--name-field-tags field--type-entity-reference field--label-inline clearfix">
                                                <div className="field__label">Tags</div>
                                                <div className="field__items">
                                                    <div className="field__item"><a href="/en/tags/cake"
                                                                                    hreflang="en">Cake</a>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div
                                            className="block block-layout-builder block-field-blocknoderecipefield-summary">


                                            <div
                                                className="clearfix text-formatted field field--name-field-summary field--type-text-long field--label-hidden field__item">
                                                <p>A traditional Victoria sponge cake, perfect for any
                                                    afternoon with a cup of tea.</p>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                                <div className="layout layout--oneplusfourgrid-section">

                                    <div className="layout__region layout__region--first">
                                        <div
                                            className="block block-layout-builder block-field-blocknoderecipefield-media-image">


                                            <div
                                                className="field field--name-field-media-image field--type-entity-reference field--label-hidden field__item">
                                                <article
                                                    className="media media--type-image media--view-mode-responsive-3x2">


                                                    <div
                                                        className="field field--name-field-media-image field--type-image field--label-visually_hidden">
                                                        <div className="field__label visually-hidden">படம்
                                                        </div>
                                                        <div className="field__item"><img
                                                            srcset={img1}
                                                            sizes="100vw"
                                                            src={img1}
                                                            alt="A classic, uncut Victoria sponge with a deep filling of butter cream and jam"
                                                            typeof="foaf:Image"/>


                                                        </div>
                                                    </div>

                                                </article>
                                            </div>

                                        </div>

                                    </div>

                                    <div className="layout__four-grid-group">

                                        <div className="layout__region layout__region--second">
                                            <div
                                                className="block block-layout-builder block-field-blocknoderecipefield-preparation-time">


                                                <div
                                                    className="field field--name-field-preparation-time field--type-integer field--label-inline clearfix">
                                                    <div className="field__label">Preparation time</div>
                                                    <div content="20" className="field__item">20 minutes
                                                    </div>
                                                </div>

                                            </div>

                                        </div>

                                        <div className="layout__region layout__region--third">
                                            <div
                                                className="block block-layout-builder block-field-blocknoderecipefield-cooking-time">


                                                <div
                                                    className="field field--name-field-cooking-time field--type-integer field--label-inline clearfix">
                                                    <div className="field__label">Cooking time</div>
                                                    <div content="20" className="field__item">20 minutes
                                                    </div>
                                                </div>

                                            </div>

                                        </div>

                                        <div className="layout__region layout__region--fourth">
                                            <div
                                                className="block block-layout-builder block-field-blocknoderecipefield-number-of-servings">


                                                <div
                                                    className="field field--name-field-number-of-servings field--type-integer field--label-inline clearfix">
                                                    <div className="field__label">Number of servings</div>
                                                    <div className="field__item">10</div>
                                                </div>

                                            </div>

                                        </div>

                                        <div className="layout__region layout__region--fifth">
                                            <div
                                                className="block block-layout-builder block-field-blocknoderecipefield-difficulty">


                                                <div
                                                    className="label-items field field--name-field-difficulty field--type-list-string field--label-inline clearfix">
                                                    <div className="field__label">Difficulty</div>
                                                    <div className="field__item">Easy</div>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>
                                <div
                                    className="layout layout--twocol-section layout--twocol-section--33-67">

                                    <div className="layout__region layout__region--first">
                                        <div
                                            className="block block-layout-builder block-field-blocknoderecipefield-ingredients">


                                            <div
                                                className="field field--name-field-ingredients field--type-string field--label-above">
                                                <div className="field__label">Ingredients</div>
                                                <div className="field__items">
                                                    <div className="field__item">225g butter or margarine
                                                    </div>
                                                    <div className="field__item">225g caster sugar</div>
                                                    <div className="field__item">225g self-raising flour
                                                    </div>
                                                    <div className="field__item">4 eggs</div>
                                                    <div className="field__item">1 tsp baking powder</div>
                                                    <div className="field__item">3 tbsp of jam for the
                                                        filling
                                                    </div>
                                                    <div className="field__item">Icing sugar to dust the
                                                        top
                                                    </div>
                                                    <div className="field__item">Cream to serve</div>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                    <div className="layout__region layout__region--second">
                                        <div
                                            className="block block-layout-builder block-field-blocknoderecipefield-recipe-instruction">


                                            <div
                                                className="clearfix text-formatted field field--name-field-recipe-instruction field--type-text-long field--label-above">
                                                <div className="field__label">Recipe instruction</div>
                                                <div className="field__item">
                                                    <ol>
                                                        <li>Preheat the oven to 350°F/180°C and grease two 8
                                                            inch cake tins.
                                                        </li>
                                                        <li>In a large bowl, mix the butter and sugar
                                                            together, then add the eggs, flour and baking
                                                            powder.
                                                        </li>
                                                        <li>Spread the mix evenly between the 2 cake tins.
                                                        </li>
                                                        <li>Place both tins in the middle of the preheated
                                                            oven for 20 minutes, before checking with a
                                                            knife. When the knife comes out clean, it's
                                                            ready!
                                                        </li>
                                                        <li>Allow to cool in the tins before moving them
                                                            onto a cooling rack.
                                                        </li>
                                                        <li>Add the jam, stack, dust with icing sugar and
                                                            serve with a big dollop of cream. Enjoy!
                                                        </li>
                                                    </ol>
                                                </div>
                                            </div>

                                        </div>

                                    </div>

                                </div>
                                <div className="layout layout--onecol">
                                    <div className="layout__region layout__region--content">
                                        <div
                                            className="block block-layout-builder block-extra-field-blocknoderecipecontent-moderation-control">


                                        </div>

                                    </div>
                                </div>

                            </div>

                        </article>

                    </div>

                </div>

            </div>

        </main>

        <div className="layout-content-bottom">
            <div className="region region-content-bottom">
                <div
                    className="views-element-container block block-views block-views-blockrecipe-collections-block"
                    id="block-umami-views-block-recipe-collections-block">

                    <h2 className="block__title">Recipe collections</h2>


                    <div className="container">
                        <div>
                            <div
                                className="view view-recipe-collections view-id-recipe_collections view-display-id-block js-view-dom-id-6caa14316baf5745487466592678fa96f165e11ec15e316ef420987ff0f7db58">


                                <div className="view-content">
                                    <div className="views-view-grid vertical cols-4 clearfix">
                                        <div className="views-col clearfix col-1">
                                            <div className="views-row row-1">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a
                                                    href="/en/tags/alcohol-free"
                                                    hreflang="en">Alcohol free</a></span></div>
                                            </div>
                                            <div className="views-row row-2">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/baked"
                                                                                 hreflang="en">Baked</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-3">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/baking"
                                                                                 hreflang="en">Baking</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-4">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/breakfast"
                                                                                 hreflang="en">Breakfast</a></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="views-col clearfix col-2">
                                            <div className="views-row row-1">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/cake"
                                                                                 hreflang="en">Cake</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-2">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/carrots"
                                                                                 hreflang="en">Carrots</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-3">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/chocolate"
                                                                                 hreflang="en">Chocolate</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-4">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a
                                                    href="/en/tags/cocktail-party" hreflang="en">Cocktail party</a></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="views-col clearfix col-3">
                                            <div className="views-row row-1">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/dairy-free"
                                                                                 hreflang="en">Dairy-free</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-2">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/dessert"
                                                                                 hreflang="en">Dessert</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-3">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a
                                                    href="/en/tags/dinner-party"
                                                    hreflang="en">Dinner party</a></span></div>
                                            </div>
                                            <div className="views-row row-4">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/drinks"
                                                                                 hreflang="en">Drinks</a></span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="views-col clearfix col-4">
                                            <div className="views-row row-1">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/egg"
                                                                                 hreflang="en">Egg</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-2">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a
                                                    href="/en/tags/grow-your-own" hreflang="en">Grow your own</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-3">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/healthy"
                                                                                 hreflang="en">Healthy</a></span>
                                                </div>
                                            </div>
                                            <div className="views-row row-4">
                                                <div className="views-field views-field-name"><span
                                                    className="field-content"><a href="/en/tags/herbs"
                                                                                 hreflang="en">Herbs</a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>


                    </div>
                </div>

            </div>

        </div>

        <div className="layout-footer">
            <footer className="footer" role="contentinfo">
                <div className="container">
                    <div className="region region-footer">
                        <div id="block-umami-footer-promo" className="block-type-footer-promo-block">

                            <div
                                className="field field--name-field-media-image field--type-entity-reference field--label-hidden field__item">
                                <article className="media media--type-image media--view-mode-medium-8-7">


                                    <div
                                        className="field field--name-field-media-image field--type-image field--label-visually_hidden">
                                        <div className="field__label visually-hidden">படம்</div>
                                        <div className="field__item"><img
                                            src={img2}
                                            width="266" height="236"
                                            alt="3 issue bundle of the Umami food magazine" loading="lazy"
                                            typeof="foaf:Image" className="image-style-medium-8-7"/>


                                        </div>
                                    </div>

                                </article>
                            </div>


                            <h2 className="block__title">
                                <div
                                    className="field field--name-field-title field--type-string field--label-hidden field__item">Umami
                                    Food Magazine
                                </div>
                            </h2>

                            <div className="footer-promo-content">

                                <div
                                    className="field field--name-field-summary field--type-string-long field--label-hidden field__item">Skills
                                    and know-how. Magazine exclusive articles, recipes and plenty of reasons
                                    to get your copy today.
                                </div>

                                <div
                                    className="field field--name-field-content-link field--type-link field--label-hidden field__item">
                                    <a href="/en/about-umami">Find out more</a></div>

                            </div>
                        </div>
                        <div id="block-umami-footer"
                             className="block block-system block-system-menu-blockfooter menu-footer-wrapper">

                            <h2 className="block__title menu-footer__title">Tell us what you think</h2>


                            <ul className="menu-footer">
                                <li className="menu-footer__item"><a href="/en/contact"
                                                                     className="menu-footer__link"
                                                                     data-drupal-link-system-path="contact">Contact</a>
                                </li>
                            </ul>


                        </div>

                    </div>

                </div>
            </footer>
        </div>

        <div className="layout-bottom">
            <div className="container">
                <div className="region region-bottom">
                    <div id="block-umami-disclaimer"
                         className="block-type-disclaimer-block block block-block-content block-block-content9b4dcd67-99f3-48d0-93c9-2c46648b29de">


                        <div
                            className="clearfix text-formatted field field--name-field-disclaimer field--type-text-long field--label-hidden field__item">
                            <p><strong>Umami Magazine &amp; Umami Publications</strong> is a fictional
                                magazine and publisher for illustrative purposes only.</p>
                        </div>

                        <div
                            className="clearfix text-formatted field field--name-field-copyright field--type-text-long field--label-hidden field__item">
                            <p>© 2022 Terms &amp; Conditions</p>
                        </div>

                    </div>

                </div>

            </div>
        </div>

    </div>
</div>

</div>
    </>
  )
}


export default Layout
